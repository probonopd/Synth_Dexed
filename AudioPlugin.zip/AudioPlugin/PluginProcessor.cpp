#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
// Helper function to create plugin parameters
juce::AudioProcessorValueTreeState::ParameterLayout AudioPluginAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // TODO: Add your plugin parameters here. For example:
    // params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "gain", 1 }, "Gain", 0.0f, 1.0f, 0.5f));
    // params.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { "mode", 1 }, "Mode", juce::StringArray { "Option1", "Option2" }, 0));

    return { params.begin(), params.end() };
}

AudioPluginAudioProcessor::AudioPluginAudioProcessor()
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       ),
       treeState (*this, nullptr, juce::Identifier ("PluginParameters"), createParameterLayout())
{
    // dexed is a std::unique_ptr, it's already initialized to nullptr by default.
    // Initialize FileLogger - logs to a file in the User's Documents directory
    auto documentsDir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory);
    auto logFile = documentsDir.getChildFile ("AudioPluginDemoLog.txt"); 
    fileLogger = std::make_unique<juce::FileLogger>(logFile, "Log started: " + juce::Time::getCurrentTime().toString (true, true), 1024 * 1024);
    juce::Logger::setCurrentLogger (fileLogger.get());
    DBG("Constructor: FileLogger initialized. Logging to: " + logFile.getFullPathName());
}

AudioPluginAudioProcessor::~AudioPluginAudioProcessor()
{
    dexed.reset(); // Reset the unique_ptr
    DBG("Destructor: Cleaning up.");
    juce::Logger::setCurrentLogger (nullptr); // Important to release the logger
    fileLogger.reset(); // Release the file logger
}

//==============================================================================
const juce::String AudioPluginAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool AudioPluginAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool AudioPluginAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool AudioPluginAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double AudioPluginAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int AudioPluginAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int AudioPluginAudioProcessor::getCurrentProgram()
{
    return 0;
}

void AudioPluginAudioProcessor::setCurrentProgram (int index)
{
    juce::ignoreUnused (index);
}

const juce::String AudioPluginAudioProcessor::getProgramName (int index)
{
    juce::ignoreUnused (index);
    return {};
}

void AudioPluginAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
    juce::ignoreUnused (index, newName);
}

//==============================================================================

void AudioPluginAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    juce::Logger::writeToLog("AudioPluginAudioProcessor::prepareToPlay called. Sample rate: " + juce::String(sampleRate));
    juce::ignoreUnused (samplesPerBlock);
    dexed.reset(); // Reset before creating a new instance
    dexed = std::make_unique<Dexed>(16, (uint16_t)sampleRate); 
    dexed->resetControllers();
    dexed->setVelocityScale(0); 



    uint8_t fmpiano_sysex[156] = {
        95, 29, 20, 50, 99, 95, 00, 00, 41, 00, 19, 00, 00, 03, 00, 06, 79, 00, 01, 00, 14, // OP6 eg_rate_1-4, level_1-4, kbd_lev_scl_brk_pt, kbd_lev_scl_lft_depth, kbd_lev_scl_rht_depth, kbd_lev_scl_lft_curve, kbd_lev_scl_rht_curve, kbd_rate_scaling, amp_mod_sensitivity, key_vel_sensitivity, operator_output_level, osc_mode, osc_freq_coarse, osc_freq_fine, osc_detune
        95, 20, 20, 50, 99, 95, 00, 00, 00, 00, 00, 00, 00, 03, 00, 00, 99, 00, 01, 00, 00, // OP5
        95, 29, 20, 50, 99, 95, 00, 00, 00, 00, 00, 00, 00, 03, 00, 06, 89, 00, 01, 00, 07, // OP4
        95, 20, 20, 50, 99, 95, 00, 00, 00, 00, 00, 00, 00, 03, 00, 02, 99, 00, 01, 00, 07, // OP3
        95, 50, 35, 78, 99, 75, 00, 00, 00, 00, 00, 00, 00, 03, 00, 07, 58, 00, 14, 00, 07, // OP2
        96, 25, 25, 67, 99, 75, 00, 00, 00, 00, 00, 00, 00, 03, 00, 02, 99, 00, 01, 00, 10, // OP1
        94, 67, 95, 60, 50, 50, 50, 50,                                                     // 4 * pitch EG rates, 4 * pitch EG level
        04, 06, 00,                                                                         // algorithm, feedback, osc sync
        34, 33, 00, 00, 00, 04,                                                             // lfo speed, lfo delay, lfo pitch_mod_depth, lfo_amp_mod_depth, lfo_sync, lfo_waveform
        03, 24,                                                                             // pitch_mod_sensitivity, transpose
        70, 77, 45, 80, 73, 65, 78, 79, 00, 00                                              // 10 * char for name ("DEFAULT   ")
      }; // FM-Piano
      

    dexed->loadVoiceParameters(fmpiano_sysex);
    dexed->setGain(3.0f);
    dexed->activate();
    juce::Logger::writeToLog("Dexed activated and default voice loaded.");
}

void AudioPluginAudioProcessor::releaseResources()
{
    juce::Logger::writeToLog("AudioPluginAudioProcessor::releaseResources called."); // Added log message
    dexed.reset(); // Reset the unique_ptr
}

bool AudioPluginAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}

void AudioPluginAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer,
                                              juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    process(buffer, midiMessages); // Call templated version
}

// Add the double-precision overload
void AudioPluginAudioProcessor::processBlock (juce::AudioBuffer<double>& buffer,
                                              juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    // Create a temporary float buffer
    juce::AudioBuffer<float> floatBuffer;
    floatBuffer.setSize (buffer.getNumChannels(), buffer.getNumSamples(), false, false, true);

    // Copy double to float
    for (int channel = 0; channel < buffer.getNumChannels(); ++channel) {
        auto* dest = floatBuffer.getWritePointer (channel);
        const auto* src = buffer.getReadPointer (channel);
        for (int sample = 0; sample < buffer.getNumSamples(); ++sample) {
            dest[sample] = static_cast<float>(src[sample]);
        }
    }

    process(floatBuffer, midiMessages); // Process using the float buffer

    // Copy float back to double
    for (int channel = 0; channel < buffer.getNumChannels(); ++channel) {
        auto* dest = buffer.getWritePointer (channel);
        const auto* src = floatBuffer.getReadPointer (channel);
        for (int sample = 0; sample < buffer.getNumSamples(); ++sample) {
            dest[sample] = static_cast<double>(src[sample]);
        }
    }
}

// Add the templated process implementation
template <typename FloatType>
void AudioPluginAudioProcessor::process (juce::AudioBuffer<FloatType>& buffer, juce::MidiBuffer& midiMessages) {
    juce::Logger::writeToLog("Process block. Samples: " + juce::String(buffer.getNumSamples()) + ", MIDI events reported by getNumEvents(): " + juce::String(midiMessages.getNumEvents()));

    auto totalNumOutputChannels = getTotalNumOutputChannels();
    auto numSamples = buffer.getNumSamples();

    for (auto i = getTotalNumInputChannels(); i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, numSamples);

    if (midiMessages.isEmpty())
    {
        juce::Logger::writeToLog("MidiBuffer is empty according to isEmpty().");
    }
    else
    {
        juce::Logger::writeToLog("MidiBuffer is NOT empty. Iterating messages...");
        for (const auto metadata : midiMessages) {
            const auto msg = metadata.getMessage();
            juce::Logger::writeToLog("MIDI Message received: " + msg.getDescription() 
                                     + " | Timestamp: " + juce::String(metadata.samplePosition)
                                     + " | Channel: " + juce::String(msg.getChannel())
                                     + " | Raw Byte 0: " + juce::String::toHexString(msg.getRawData()[0]) // Corrected to use toHexString
                                     + " | Size: " + juce::String(msg.getRawDataSize()));

            if (msg.isNoteOn()) {
                juce::Logger::writeToLog("  -> Interpreted as Note On. Note: " + juce::String(msg.getNoteNumber()) + " Velocity: " + juce::String(msg.getVelocity()));
                if (dexed) dexed->keydown((uint8_t)msg.getNoteNumber(), (uint8_t)msg.getVelocity());
            } else if (msg.isNoteOff()) {
                juce::Logger::writeToLog("  -> Interpreted as Note Off. Note: " + juce::String(msg.getNoteNumber()));
                if (dexed) dexed->keyup((uint8_t)msg.getNoteNumber());
            } else if (msg.isController()) {
                juce::Logger::writeToLog("  -> Interpreted as Controller. Number: " + juce::String(msg.getControllerNumber()) + " Value: " + juce::String(msg.getControllerValue()));
            } else if (msg.isPitchWheel()) {
                juce::Logger::writeToLog("  -> Interpreted as Pitch Wheel. Value: " + juce::String(msg.getPitchWheelValue()));
            } else {
                juce::Logger::writeToLog("  -> Interpreted as Other MIDI message type.");
            }
        }
    }

    // Render Dexed output
    if (dexed) {
        std::vector<int16_t> monoBuffer(numSamples);
        dexed->getSamples(monoBuffer.data(), (uint16_t)numSamples);

        bool isSilent = true;
        for(int i = 0; i < juce::jmin(50, numSamples); ++i) { 
            if (monoBuffer[i] != 0) {
                isSilent = false;
                juce::Logger::writeToLog("Dexed monoBuffer (first non-zero up to 50): [" + juce::String(i) + "] = " + juce::String(monoBuffer[i]));
                break;
            }
        }
        if (isSilent && numSamples > 0) juce::Logger::writeToLog("Dexed monoBuffer appears silent for first 50 samples.");

        for (int ch = 0; ch < totalNumOutputChannels; ++ch) {
            FloatType* out = buffer.getWritePointer(ch);
            for (int i = 0; i < numSamples; ++i) {
                out[i] = monoBuffer[i] / 32768.0f; 
            }
        }
    } else {
        juce::Logger::writeToLog("Dexed object is null in process block!");
        buffer.clear();
    }
}

//==============================================================================
bool AudioPluginAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* AudioPluginAudioProcessor::createEditor()
{
    return new AudioPluginAudioProcessorEditor (*this);
}

//==============================================================================
void AudioPluginAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
    juce::ignoreUnused (destData);
}

void AudioPluginAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
    juce::ignoreUnused (data, sizeInBytes);
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new AudioPluginAudioProcessor();
}
